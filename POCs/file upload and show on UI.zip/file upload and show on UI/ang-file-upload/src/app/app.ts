import { Component } from '@angular/core';
import { AppService } from './app-service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  selectedFile: File | null = null;
  fileUrl: string = '';

  constructor(private uploadService: AppService) {}

  isImage(url: string): boolean {
    return /\.(jpeg|jpg|png|gif)$/i.test(url);
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    console.log('this.selectedFile', this.selectedFile);
  }

  onUpload() {
    if (!this.selectedFile) return;

    this.uploadService.uploadFile(this.selectedFile).subscribe({
      next: (res) => {
        this.fileUrl = res.filePath;
      },
      error: (err) => {
        console.error('Upload failed', err);
      },
    });
  }
}
